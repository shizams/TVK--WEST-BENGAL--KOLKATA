---
name: Sangam Digital Narrative
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f3'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#5a413d'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f1f1f1'
  outline: '#8e706c'
  outline-variant: '#e2bfb9'
  surface-tint: '#b22b1d'
  primary: '#570000'
  on-primary: '#ffffff'
  primary-container: '#800000'
  on-primary-container: '#ff8371'
  inverse-primary: '#ffb4a8'
  secondary: '#705d00'
  on-secondary: '#ffffff'
  secondary-container: '#fcd400'
  on-secondary-container: '#6e5c00'
  tertiary: '#272626'
  on-tertiary: '#ffffff'
  tertiary-container: '#3d3c3c'
  on-tertiary-container: '#a8a6a6'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad4'
  primary-fixed-dim: '#ffb4a8'
  on-primary-fixed: '#410000'
  on-primary-fixed-variant: '#8f0f07'
  secondary-fixed: '#ffe16d'
  secondary-fixed-dim: '#e9c400'
  on-secondary-fixed: '#221b00'
  on-secondary-fixed-variant: '#544600'
  tertiary-fixed: '#e5e2e1'
  tertiary-fixed-dim: '#c8c6c5'
  on-tertiary-fixed: '#1c1b1b'
  on-tertiary-fixed-variant: '#474746'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 8px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 64px
---

## Brand & Style

The design system is a synthesis of ancient Tamil heritage and forward-looking digital governance. It avoids the chaotic aesthetics of traditional political design in favor of a **Corporate-Modern** approach that signals discipline, security, and institutional reliability.

The visual narrative is driven by "Brave Prosperity"—combining the strength of the fighting elephant with the victorious symbolism of the *Vaagai* flower. The aesthetic is clean and structured, utilizing heavy whitespace and precise alignment to communicate a "Digital First" secular social justice movement. The UI should evoke a sense of organized power, moving away from populist clutter toward a professional, tech-enabled collective.

## Colors

The palette is anchored by **Imperial Maroon**, representing bravery and the deep roots of Tamil heritage, and **Victory Gold**, symbolizing prosperity and the *Vaagai* flower. 

- **Primary (Maroon):** Used for key branding elements, primary actions, and structural headers. It must command the page without being overbearing.
- **Secondary (Yellow):** Used sparingly as an accent color for high-visibility highlights, active states, and call-to-action iconography.
- **Surface & Neutral:** A clean spectrum of cool grays and whites provides the "Digital First" canvas, ensuring the bold primary colors feel modern and not dated.
- **Success State:** A specific "Growth Green" (#2E7D32) is used for secular progress and membership confirmation states.

## Typography

The typography system prioritizes authority and multi-script legibility (English and Tamil/Bengali equivalents). 

- **Headlines:** Uses **Plus Jakarta Sans** for its geometric clarity and modern professional feel. Heavy weights (Bold/ExtraBold) are required to convey "Brave" intent.
- **Body:** **Inter** is the workhorse for all data-heavy sections and long-form reading, ensuring maximum legibility on low-end mobile devices.
- **Technical Labels:** **JetBrains Mono** is used for membership IDs, timestamps, and data labels to reinforce the "Digital First" and "Secure" narrative.

## Layout & Spacing

The layout follows a **Fixed Grid** philosophy on desktop to maintain a structured, institutional feel, transitioning to a fluid model on mobile. 

- **Grid:** 12-column grid for desktop, 4-column for mobile.
- **Rhythm:** An 8px linear scale governs all padding and margins. 
- **Digital Membership Cards:** These should utilize a 3:2 aspect ratio, designed to fit perfectly within mobile viewports without scrolling.
- **Alignment:** Strong left-alignment for text to mirror formal document structures, with centered layouts reserved only for high-impact landing hero sections.

## Elevation & Depth

This design system uses **Tonal Layers** and **Low-Contrast Outlines** rather than heavy shadows to maintain a "clean-tech" aesthetic. 

- **Surface Levels:** The background is the lowest level (Level 0). Cards and containers sit on Level 1, defined by a 1px border (#E0E0E0) rather than a shadow.
- **Interaction Depth:** Only active "Membership Cards" or "Primary Action Buttons" receive a subtle, ultra-diffused maroon-tinted shadow to indicate interactability. 
- **Security Feel:** Input fields use an "inner-step" bezel effect (subtle top-inner shadow) to feel like physical, secure slots for data entry.

## Shapes

The shape language is **Soft** but disciplined. 

- **General Elements:** A base radius of 4px (`rounded-sm`) is used for buttons and inputs to maintain a serious, corporate edge.
- **Feature Cards:** Larger containers like the "Digital Membership Card" use 12px (`rounded-lg`) to feel premium and handheld.
- **Iconography:** Icons should feature sharp terminals with slightly rounded joins, echoing the fusion of ancient stone carvings and modern vector art.

## Components

### Digital Membership Card
The signature component of this design system. It features a Maroon-to-Black subtle gradient background, the *Vaagai* flower as a semi-transparent watermark, and the user's data rendered in Gold and White using the Label typography.

### Secure Input Fields
Fields feature a "Validated" state that uses a thick 2px Maroon left-border when focused. The transition to a "Success" state (Green) must be clear, accompanied by a small checkmark icon to signify security.

### Buttons
- **Primary:** Solid Maroon with White text. No gradients. High-contrast and impactful.
- **Secondary:** Transparent with a 2px Maroon border.
- **Action:** For "Join Now" or "Donate," use Gold background with Black text to ensure maximum conversion visibility.

### Chips & Tags
Used for identifying regional chapters or social justice categories. These should be rectangular with the 4px radius, using light Maroon backgrounds with dark Maroon text.

### Progress Indicators
Linear bars representing "Movement Growth" or "Target Goals" use a Yellow fill on a dark Maroon track, providing high contrast and energy.